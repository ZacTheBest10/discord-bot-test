module.exports = {
    customIdRegex: /^verificar_usuario_(\d+)$/,
    async execute(interaction) {
        const match = interaction.customId.match(this.customIdRegex);
        if (!match) return;

        const cargoId = match[1];
        const cargo = interaction.guild.roles.cache.get(cargoId);

        if (!cargo) {
            return await interaction.reply({ content: '❌ O cargo de verificação não foi encontrado.', ephemeral: true });
        }

        if (interaction.member.roles.cache.has(cargo.id)) {
            return await interaction.reply({ content: '⚠️ Você já está verificado.', ephemeral: true });
        }

        await interaction.member.roles.add(cargo);
        await interaction.reply({ content: '✅ Você foi verificado com sucesso!', ephemeral: true });
    }
};