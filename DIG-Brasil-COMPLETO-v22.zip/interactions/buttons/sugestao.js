const { ModalBuilder, TextInputBuilder, ActionRowBuilder, TextInputStyle, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    customId: 'abrir_sugestao',
    async execute(interaction) {
        const modal = new ModalBuilder()
            .setCustomId('modal_sugestao')
            .setTitle('Nova Sugestão');

        const sugestaoInput = new TextInputBuilder()
            .setCustomId('sugestao_texto')
            .setLabel('Digite sua sugestão')
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(true);

        const row = new ActionRowBuilder().addComponents(sugestaoInput);
        modal.addComponents(row);

        await interaction.showModal(modal);
    }
};