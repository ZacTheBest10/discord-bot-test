const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    customId: 'modal_sugestao',
    async execute(interaction) {
        const texto = interaction.fields.getTextInputValue('sugestao_texto');

        const embed = new EmbedBuilder()
            .setTitle('📝 Nova Sugestão')
            .setDescription(`**Autor:** ${interaction.user.tag}

**Sugestão:**
${texto}`)
            .setColor('#4b5563')
            .setTimestamp();

        const canalLogs = interaction.guild.channels.cache.find(c => c.name.includes('sugestoes')) || null;
        if (canalLogs) canalLogs.send({ embeds: [embed] });

        fs.appendFileSync(path.join(__dirname, '../../database/logs_sugestoes.log'),
            `Sugestão de ${interaction.user.tag}: ${texto}\n`);

        await interaction.reply({ content: '✅ Sua sugestão foi enviada com sucesso!', ephemeral: true });
    }
};