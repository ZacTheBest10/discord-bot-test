module.exports = {
    name: 'interactionCreate',
    async execute(interaction) {
        if (!interaction.isButton()) return;

        if (interaction.customId === 'verificar_usuario') {
            const cargo = interaction.guild.roles.cache.find(r => r.name === 'Verificado');
            if (!cargo) return interaction.reply({ content: 'Cargo "Verificado" não encontrado.', ephemeral: true });

            await interaction.member.roles.add(cargo);
            return interaction.reply({ content: 'Você foi verificado com sucesso!', ephemeral: true });
        }

        if (interaction.customId === 'baterponto') {
            const fs = require('fs');
            const path = './database/ponto_staff.log';
            const log = `[${new Date().toLocaleString()}] ${interaction.user.tag} bateu ponto\n`;
            fs.appendFileSync(path, log);
            return interaction.reply({ content: 'Ponto registrado com sucesso.', ephemeral: true });
        }

        if (interaction.customId === 'ver_logs') {
            return interaction.reply({ content: 'Confira o canal 📒logs-mod para ver os registros.', ephemeral: true });
        }

        if (interaction.customId === 'encerrar_todos_tickets') {
            return interaction.reply({ content: 'Todos os tickets foram encerrados com sucesso. (mock)', ephemeral: true });
        }
    }
};