const { ActivityType } = require('discord.js');

module.exports = {
  name: 'ready',
  once: true,
  execute(client) {
    const status = [
      { name: 'DIG Brasil - /ajuda', type: ActivityType.Playing },
      { name: '👀 Monitorando seu servidor', type: ActivityType.Watching },
      { name: '🛡 Protegendo sua comunidade', type: ActivityType.Competing }
    ];

    let i = 0;
    setInterval(() => {
      if (i >= status.length) i = 0;
      client.user.setActivity(status[i]);
      i++;
    }, 10000);

    console.log(`${client.user.tag} está online.`);
  }
};
