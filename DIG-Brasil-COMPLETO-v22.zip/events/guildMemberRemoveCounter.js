const updateCounters = require('../systems/contador/updateCounters');

module.exports = {
  name: 'guildMemberRemove',
  once: false,
  async execute(member) {
    updateCounters(member.guild);
  }
};
