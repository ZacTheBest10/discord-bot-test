const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'interactionCreate',
    async execute(interaction) {
        if (!interaction.isButton()) return;
        if (interaction.customId === 'verificar_usuario') {
            const cargo = interaction.guild.roles.cache.find(r => r.name.toLowerCase().includes('verificado'));

            if (!cargo) {
                return interaction.reply({ content: '❌ Cargo "verificado" não encontrado.', ephemeral: true });
            }

            if (interaction.member.roles.cache.has(cargo.id)) {
                return interaction.reply({ content: '✅ Você já está verificado.', ephemeral: true });
            }

            await interaction.member.roles.add(cargo);
            
            const embed = new EmbedBuilder()
                .setTitle('✅ Verificação concluída')
                .setDescription('Você foi verificado com sucesso e agora tem acesso ao servidor!')
                .setColor('#006400'); // Verde escuro

            await interaction.reply({ embeds: [embed], ephemeral: true });
        }
    }
};