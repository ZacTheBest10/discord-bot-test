const updateCounters = require('../systems/contador/updateCounters');

module.exports = {
  name: 'guildMemberAdd',
  once: false,
  async execute(member) {
    updateCounters(member.guild);
  }
};
