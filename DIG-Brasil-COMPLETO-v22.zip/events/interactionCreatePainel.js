module.exports = {
    name: 'interactionCreate',
    async execute(interaction) {
        if (!interaction.isButton()) return;

        const cargosMap = {
            cargo_games: 'Gamer',
            cargo_aviso: 'Avisos',
            cargo_eventos: 'Eventos'
        };

        const nomeCargo = cargosMap[interaction.customId];
        if (!nomeCargo) return;

        const cargo = interaction.guild.roles.cache.find(r => r.name.toLowerCase() === nomeCargo.toLowerCase());
        if (!cargo) return interaction.reply({ content: `❌ Cargo "${nomeCargo}" não encontrado.`, ephemeral: true });

        const membroTemCargo = interaction.member.roles.cache.has(cargo.id);

        if (membroTemCargo) {
            await interaction.member.roles.remove(cargo);
            return interaction.reply({ content: `❌ Cargo **${nomeCargo}** removido com sucesso.`, ephemeral: true });
        } else {
            await interaction.member.roles.add(cargo);
            return interaction.reply({ content: `✅ Cargo **${nomeCargo}** adicionado com sucesso.`, ephemeral: true });
        }
    }
};