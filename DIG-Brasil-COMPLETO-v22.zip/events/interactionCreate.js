const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'interactionCreate',
    async execute(interaction, client) {
        if (interaction.isButton()) {
            if (interaction.customId === 'botaoVerificar') {
                const cargoId = 'ID_DO_CARGO_VERIFICADO'; // Substitua

                if (interaction.member.roles.cache.has(cargoId)) {
                    return await interaction.reply({ content: 'Você já está verificado.', ephemeral: true });
                }

                try {
                    await interaction.member.roles.add(cargoId);
                    await interaction.reply({ content: '✅ Você foi verificado com sucesso!', ephemeral: true });
                } catch (error) {
                    console.error(error);
                    await interaction.reply({ content: '❌ Ocorreu um erro ao tentar verificar você.', ephemeral: true });
                }
            }
        }

        if (interaction.isModalSubmit() && interaction.customId === 'modalSugestao') {
            const sugestaoTexto = interaction.fields.getTextInputValue('sugestaoTexto');
            const sugestaoChannelId = 'ID_DO_CANAL_SUGESTOES';

            const embed = new EmbedBuilder()
                .setTitle('📨 Nova Sugestão Recebida')
                .setDescription(`> ${sugestaoTexto}`)
                .setColor('#2c2f33')
                .setFooter({ text: `Sugestão enviada por ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() })
                .setTimestamp();

            const channel = await client.channels.fetch(sugestaoChannelId);
            if (channel) {
                await channel.send({ embeds: [embed] });
            }

            await interaction.reply({ content: '✅ Sua sugestão foi enviada com sucesso!', ephemeral: true });
        }
    }
};
