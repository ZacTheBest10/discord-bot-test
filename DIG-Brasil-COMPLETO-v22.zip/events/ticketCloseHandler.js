const fs = require('fs');
const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'interactionCreate',
    async execute(interaction) {
        if (!interaction.isButton()) return;

        if (interaction.customId === 'fechar_ticket') {
            const logPath = './database/logs_tickets.log';
            const content = `[${new Date().toLocaleString()}] ${interaction.user.tag} fechou o ticket ${interaction.channel.name}\n`;

            fs.appendFileSync(logPath, content);

            try {
                await interaction.user.send({
                    embeds: [
                        new EmbedBuilder()
                            .setTitle('📪 Ticket Encerrado')
                            .setDescription(`Seu ticket "${interaction.channel.name}" foi encerrado com sucesso.`)
                            .setColor(0x1c1c1c)
                    ]
                });
            } catch {}

            await interaction.channel.delete();
        }
    }
};