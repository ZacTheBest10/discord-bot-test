const fs = require('fs');
const { Events } = require('discord.js');
const db = require('../database/contadores.json');

async function atualizarContadores(guild) {
    const info = db[guild.id];
    if (!info) return;

    const total = guild.memberCount;
    const online = guild.members.cache.filter(m => m.presence?.status === 'online').size;
    const criado = guild.createdAt.toLocaleDateString('pt-BR');

    if (info.total) {
        const canal = guild.channels.cache.get(info.total);
        if (canal) canal.setName(`👥 Membros: ${total}`).catch(() => {});
    }

    if (info.online) {
        const canal = guild.channels.cache.get(info.online);
        if (canal) canal.setName(`🟢 Online: ${online}`).catch(() => {});
    }

    if (info.criado) {
        const canal = guild.channels.cache.get(info.criado);
        if (canal) canal.setName(`📆 Criado em: ${criado}`).catch(() => {});
    }
}

module.exports = {
    name: Events.GuildMemberAdd,
    async execute(member) {
        atualizarContadores(member.guild);
    }
};

module.exports.updateAll = atualizarContadores;