const { ChannelType, PermissionFlagsBits, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'interactionCreate',
  async execute(interaction) {
    if (!interaction.isButton()) return;

    if (interaction.customId === 'abrir_ticket') {
      const user = interaction.user;
      const guild = interaction.guild;
      const canalExistente = guild.channels.cache.find(c => c.name === \`ticket-\${user.username.toLowerCase()}\`);
      if (canalExistente) return interaction.reply({ content: '❌ Você já possui um ticket aberto.', ephemeral: true });

      const canal = await guild.channels.create({
        name: \`ticket-\${user.username}\`,
        type: ChannelType.GuildText,
        permissionOverwrites: [
          {
            id: guild.id,
            deny: [PermissionFlagsBits.ViewChannel],
          },
          {
            id: user.id,
            allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages],
          },
          {
            id: 'ID_DO_CARGO_STAFF',
            allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages],
          }
        ]
      });

      const embed = new EmbedBuilder()
        .setTitle('🎟️ Ticket Aberto')
        .setDescription('A equipe de suporte foi notificada. Descreva seu problema abaixo.')
        .setColor('#2F4F4F'); // Cinza escuro

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId('fechar_ticket')
          .setLabel('Fechar Ticket')
          .setStyle(ButtonStyle.Danger)
      );

      await canal.send({ content: \`Ticket de <@${user.id}>\`, embeds: [embed], components: [row] });
      await interaction.reply({ content: \`✅ Ticket criado: <#${canal.id}>\`, ephemeral: true });
    }

    if (interaction.customId === 'fechar_ticket') {
      const logChannel = interaction.guild.channels.cache.find(c => c.name === 'logs-ticket');
      const mensagens = await interaction.channel.messages.fetch({ limit: 100 });
      const transcript = mensagens.map(m => \`[\${m.author.tag}]: \${m.content}\`).reverse().join('\n');
      
      const filePath = path.join(__dirname, \`../transcripts/\${interaction.channel.name}.txt\`);
      fs.writeFileSync(filePath, transcript);

      if (logChannel) {
        await logChannel.send({ content: \`📄 Transcript de \${interaction.channel.name}:\`, files: [filePath] });
      }

      await interaction.channel.send('🔒 Este ticket será fechado em 5 segundos...');
      setTimeout(() => interaction.channel.delete(), 5000);
    }
  }
};
