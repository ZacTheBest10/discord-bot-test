const { updateAll } = require('./contadorAtualizar.js');

module.exports = {
    name: 'ready',
    async execute(client) {
        for (const guild of client.guilds.cache.values()) {
            updateAll(guild);
        }
    }
};