const { registrarMensagem } = require('../systems/recompensas');

module.exports = {
    name: 'messageCreate',
    async execute(message) {
        if (message.author.bot || !message.guild) return;

        const novoNivel = registrarMensagem(message.author.id);

        if (novoNivel !== null) {
            message.channel.send({
                content: `🎉 Parabéns ${message.author}, você alcançou o nível **${novoNivel}** por sua atividade no servidor!`
            });
        }
    }
};