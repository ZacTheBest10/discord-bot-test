const { ChannelType, PermissionsBitField, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    name: 'interactionCreate',
    async execute(interaction) {
        if (!interaction.isButton()) return;

        if (!interaction.customId.startsWith('ticket_')) return;

        const tipo = interaction.customId.split('_')[1];
        const categoria = {
            suporte: '🛠️・suporte',
            denuncia: '🔒・denuncias',
            sugestao: '📝・sugestoes'
        };

        const canalNome = `${tipo}-${interaction.user.username}`.toLowerCase();

        const canal = await interaction.guild.channels.create({
            name: canalNome,
            type: ChannelType.GuildText,
            parent: null,
            permissionOverwrites: [
                {
                    id: interaction.guild.id,
                    deny: [PermissionsBitField.Flags.ViewChannel]
                },
                {
                    id: interaction.user.id,
                    allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages]
                },
                {
                    id: interaction.client.user.id,
                    allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages]
                }
            ]
        });

        const embed = new EmbedBuilder()
            .setTitle(`Ticket de ${interaction.user.username}`)
            .setDescription(`Categoria: **${categoria[tipo]}**
Aguarde, a equipe responderá em breve.`)
            .setColor(0x2c3e50)
            .setFooter({ text: 'Use o botão abaixo para encerrar o ticket.' });

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('fechar_ticket')
                .setLabel('Fechar')
                .setStyle(ButtonStyle.Danger)
        );

        await canal.send({ content: `<@${interaction.user.id}>`, embeds: [embed], components: [row] });
        await interaction.reply({ content: `Seu ticket foi criado em ${canal}`, ephemeral: true });
    }
};