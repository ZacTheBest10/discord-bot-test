module.exports = {
  name: 'interactionCreate',
  async execute(interaction) {
    if (!interaction.isButton()) return;

    if (interaction.customId === 'verificado') {
      const cargo = interaction.guild.roles.cache.find(r => r.name.toLowerCase() === 'verificado');
      if (!cargo) return interaction.reply({ content: 'Cargo "verificado" não encontrado.', ephemeral: true });

      await interaction.member.roles.add(cargo);
      await interaction.reply({ content: 'Você foi verificado com sucesso!', ephemeral: true });
    }
  }
};
