const protection = require('../systems/antiraid/protection');

module.exports = {
  name: 'guildMemberAdd',
  once: false,
  async execute(member) {
    if (member.user.bot) {
      protection(member.guild, member.client);
    }
  }
};
