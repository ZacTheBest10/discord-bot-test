const { updateAll } = require('./contadorAtualizar.js');
module.exports = {
    name: 'guildMemberRemove',
    async execute(member) {
        updateAll(member.guild);
    }
};