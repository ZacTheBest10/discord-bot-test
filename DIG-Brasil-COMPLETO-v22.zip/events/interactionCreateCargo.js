module.exports = {
  name: 'interactionCreate',
  async execute(interaction) {
    if (!interaction.isButton()) return;

    if (interaction.customId === 'cargo_exemplo') {
      const cargo = interaction.guild.roles.cache.find(r => r.name.toLowerCase() === 'exemplo');
      if (!cargo) return interaction.reply({ content: 'Cargo "exemplo" não encontrado.', ephemeral: true });

      await interaction.member.roles.add(cargo);
      await interaction.reply({ content: 'Cargo atribuído com sucesso!', ephemeral: true });
    }
  }
};
