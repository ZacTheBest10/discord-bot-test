module.exports = {
    name: 'interactionCreate',
    async execute(interaction) {
        if (!interaction.isButton()) return;

        if (interaction.customId === 'sugestao_aprovar') {
            await interaction.update({ content: '✅ Sugestão aprovada por um administrador.', components: [], embeds: interaction.message.embeds });
        }

        if (interaction.customId === 'sugestao_rejeitar') {
            await interaction.update({ content: '❌ Sugestão rejeitada por um administrador.', components: [], embeds: interaction.message.embeds });
        }
    }
};