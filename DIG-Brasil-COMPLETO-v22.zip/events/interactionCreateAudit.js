const fs = require('fs');

module.exports = {
    name: 'interactionCreate',
    async execute(interaction) {
        if (!interaction.isChatInputCommand()) return;

        const log = `[${new Date().toLocaleString()}] ${interaction.user.tag} usou /${interaction.commandName}\n`;
        fs.appendFileSync('./database/comandos_usados.log', log);

        console.log(log.trim()); // opcional para debug
    }
};