const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, ComponentType } = require('discord.js');

module.exports = async function confirmar(interaction, acao, acaoConfirmada) {
  const embed = new EmbedBuilder()
    .setTitle('⚠️ Confirmação Necessária')
    .setDescription(`Tem certeza que deseja **${acao}**?`)
    .setColor('#8B0000');

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('confirmar')
      .setLabel('Confirmar')
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId('cancelar')
      .setLabel('Cancelar')
      .setStyle(ButtonStyle.Secondary)
  );

  const msg = await interaction.reply({ embeds: [embed], components: [row], ephemeral: true, fetchReply: true });

  const filtro = i => i.user.id === interaction.user.id;
  const coletor = msg.createMessageComponentCollector({ componentType: ComponentType.Button, time: 15000 });

  coletor.on('collect', async i => {
    if (i.customId === 'confirmar') {
      await acaoConfirmada();
      await i.update({ content: '✅ Ação confirmada.', embeds: [], components: [] });
    } else if (i.customId === 'cancelar') {
      await i.update({ content: '❌ Ação cancelada.', embeds: [], components: [] });
    }
  });

  coletor.on('end', async collected => {
    if (collected.size === 0) {
      await msg.edit({ content: '⏳ Tempo esgotado.', embeds: [], components: [] });
    }
  });
};
