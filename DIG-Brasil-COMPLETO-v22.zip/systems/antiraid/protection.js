const { AuditLogEvent, PermissionsBitField } = require('discord.js');

module.exports = async (guild, client) => {
  const auditLogs = await guild.fetchAuditLogs({ type: AuditLogEvent.BotAdd });
  const entry = auditLogs.entries.first();

  if (entry) {
    const executor = entry.executor;
    if (executor.id === client.user.id) return;

    const membro = await guild.members.fetch(executor.id);

    try {
      await membro.ban({ reason: 'Possível ataque de raid - adicionou bot.' });
      const canal = guild.channels.cache.find(c => c.name === 'logs-mod');
      if (canal) {
        canal.send(`🚨 | **${executor.tag}** foi banido automaticamente por adicionar bots ao servidor.`);
      }
    } catch (e) {
      console.error('Erro ao banir por raid:', e);
    }
  }
};
