module.exports = async function updateCounters(guild) {
  const totalChannel = guild.channels.cache.find(c => c.name?.startsWith('👥 Total:'));
  const onlineChannel = guild.channels.cache.find(c => c.name?.startsWith('🟢 Online:'));
  const createdChannel = guild.channels.cache.find(c => c.name?.startsWith('📆 Criado:'));

  const onlineMembers = guild.members.cache.filter(m => m.presence?.status === 'online').size;
  const totalMembers = guild.memberCount;
  const createdAt = guild.createdAt.toLocaleDateString('pt-BR');

  if (totalChannel) await totalChannel.setName(`👥 Total: ${totalMembers}`);
  if (onlineChannel) await onlineChannel.setName(`🟢 Online: ${onlineMembers}`);
  if (createdChannel) await createdChannel.setName(`📆 Criado: ${createdAt}`);
};
