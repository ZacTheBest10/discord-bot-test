module.exports = async function logModeracao(client, { action, user, reason, moderator }) {
  const canalLogs = client.channels.cache.find(c => c.name === 'logs-mod');
  if (!canalLogs) return;

  const { EmbedBuilder } = require('discord.js');
  const embed = new EmbedBuilder()
    .setTitle('📄 Log de Moderação')
    .addFields(
      { name: 'Ação', value: action, inline: true },
      { name: 'Usuário', value: user.tag, inline: true },
      { name: 'Motivo', value: reason || 'Não especificado', inline: false },
      { name: 'Moderador', value: moderator.tag, inline: true }
    )
    .setColor('#1B263B')
    .setTimestamp();

  canalLogs.send({ embeds: [embed] });
};
