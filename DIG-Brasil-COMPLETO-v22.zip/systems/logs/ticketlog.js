module.exports = async function logTicket(client, { user, action, channel }) {
  const canalLogs = client.channels.cache.find(c => c.name === 'logs-ticket');
  if (!canalLogs) return;

  const { EmbedBuilder } = require('discord.js');
  const embed = new EmbedBuilder()
    .setTitle('🎟️ Log de Ticket')
    .addFields(
      { name: 'Usuário', value: user.tag, inline: true },
      { name: 'Ação', value: action, inline: true },
      { name: 'Canal', value: channel.name, inline: true }
    )
    .setColor('#2F4F4F')
    .setTimestamp();

  canalLogs.send({ embeds: [embed] });
};
