const { Events, AuditLogEvent } = require('discord.js');

module.exports = {
    name: Events.GuildAuditLogEntryCreate,
    async execute(entry, guild) {
        const logChannel = guild.channels.cache.find(c => c.name === '📒logs-mod');

        if (!logChannel) return;

        const embed = {
            title: '🛠️ Registro de Moderação',
            color: 0x2c3e50,
            fields: [
                { name: 'Ação', value: entry.action, inline: true },
                { name: 'Executor', value: `<@${entry.executorId}>`, inline: true },
                { name: 'Alvo', value: `<@${entry.targetId}>`, inline: true },
            ],
            timestamp: new Date()
        };

        logChannel.send({ embeds: [embed] });
    }
};