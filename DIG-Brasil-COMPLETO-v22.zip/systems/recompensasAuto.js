const fs = require('fs');
const path = require('path');
const userDataPath = path.join(__dirname, '..', 'database', 'recompensas.json');

const niveisRecompensas = {
    5: 'ID_DO_CARGO_1',
    10: 'ID_DO_CARGO_2',
    20: 'ID_DO_CARGO_3'
};

module.exports = async (message, client) => {
    if (message.author.bot || !message.guild) return;

    let userData = {};
    if (fs.existsSync(userDataPath)) {
        userData = JSON.parse(fs.readFileSync(userDataPath));
    }

    const userId = message.author.id;

    if (!userData[userId]) {
        userData[userId] = { mensagens: 0, nivel: 0 };
    }

    userData[userId].mensagens += 1;

    const mensagens = userData[userId].mensagens;
    const novoNivel = Math.floor(mensagens / 20);

    if (novoNivel > userData[userId].nivel) {
        userData[userId].nivel = novoNivel;

        const membro = await message.guild.members.fetch(userId);
        const canal = message.guild.systemChannel || message.channel;

        canal.send(`🎉 Parabéns ${membro}, você alcançou o **nível ${novoNivel}**!`);

        if (niveisRecompensas[novoNivel]) {
            const cargo = message.guild.roles.cache.get(niveisRecompensas[novoNivel]);
            if (cargo && !membro.roles.cache.has(cargo.id)) {
                membro.roles.add(cargo);
                canal.send(`🎁 ${membro}, você recebeu o cargo **${cargo.name}** por atingir o nível ${novoNivel}!`);
            }
        }
    }

    fs.writeFileSync(userDataPath, JSON.stringify(userData, null, 4));
};