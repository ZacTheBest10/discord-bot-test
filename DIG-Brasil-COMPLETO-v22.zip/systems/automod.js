const palavrasProibidas = ['palavrão1', 'palavrão2', 'ofensa1', 'ofensa2'];

module.exports = {
    name: 'messageCreate',
    async execute(message) {
        if (message.author.bot || !message.guild) return;

        const conteudo = message.content.toLowerCase();
        const encontrou = palavrasProibidas.find(palavra => conteudo.includes(palavra));

        if (encontrou) {
            await message.delete();
            return message.channel.send(`🚫 ${message.author}, sua mensagem foi removida por conter linguagem inapropriada.`);
        }
    }
};