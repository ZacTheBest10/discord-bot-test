const fs = require('fs');
const path = require('path');
const userDataPath = path.join(__dirname, '..', 'database', 'recompensas.json');
let userData = {};

if (fs.existsSync(userDataPath)) {
    userData = JSON.parse(fs.readFileSync(userDataPath));
}

function salvarDados() {
    fs.writeFileSync(userDataPath, JSON.stringify(userData, null, 4));
}

function registrarMensagem(userId) {
    if (!userData[userId]) {
        userData[userId] = { mensagens: 0, nivel: 0 };
    }

    userData[userId].mensagens += 1;

    const nivelAtual = userData[userId].nivel;
    const novoNivel = Math.floor(userData[userId].mensagens / 20);

    if (novoNivel > nivelAtual) {
        userData[userId].nivel = novoNivel;
        salvarDados();
        return novoNivel;
    }

    salvarDados();
    return null;
}

module.exports = { registrarMensagem };