const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, TextInputBuilder, ModalBuilder, TextInputStyle } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('sugestao')
        .setDescription('Envie uma sugestão para o servidor.'),
    async execute(interaction) {
        const modal = new ModalBuilder()
            .setCustomId('modalSugestao')
            .setTitle('Envie sua sugestão');

        const sugestaoInput = new TextInputBuilder()
            .setCustomId('sugestaoTexto')
            .setLabel('Digite sua sugestão')
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(true);

        const row = new ActionRowBuilder().addComponents(sugestaoInput);
        modal.addComponents(row);

        await interaction.showModal(modal);
    }
};
