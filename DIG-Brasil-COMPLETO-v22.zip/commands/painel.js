const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('painel')
        .setDescription('Abre o painel da equipe staff'),

    async execute(interaction) {
        if (!interaction.member.roles.cache.some(r => r.name === 'Staff')) {
            return interaction.reply({ content: 'Apenas membros da equipe podem acessar este painel.', ephemeral: true });
        }

        const embed = new EmbedBuilder()
            .setTitle('📌 Painel da Equipe DIG Brasil')
            .setDescription('Utilize os botões abaixo para realizar ações rápidas.')
            .setColor(0x2c3e50)
            .setFooter({ text: 'Ações administrativas rápidas' });

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('baterponto')
                .setLabel('Bater Ponto')
                .setStyle(ButtonStyle.Success),
            new ButtonBuilder()
                .setCustomId('ver_logs')
                .setLabel('Ver Logs')
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId('encerrar_todos_tickets')
                .setLabel('Encerrar Tickets')
                .setStyle(ButtonStyle.Danger)
        );

        await interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
    }
};