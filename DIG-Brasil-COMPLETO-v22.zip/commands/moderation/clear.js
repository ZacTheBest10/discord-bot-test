const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('clear')
    .setDescription('Apaga mensagens de um canal.')
    .addIntegerOption(option => option.setName('quantidade').setDescription('Quantidade de mensagens a apagar (máx. 100)').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

  async execute(interaction) {
    const amount = interaction.options.getInteger('quantidade');

    if (amount < 1 || amount > 100) {
      return interaction.reply({ content: 'Você deve escolher entre 1 e 100 mensagens.', ephemeral: true });
    }

    await interaction.channel.bulkDelete(amount, true);

    await interaction.reply({ content: `🧹 ${amount} mensagens apagadas com sucesso!`, ephemeral: true });
  }
};
