const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Expulsa um membro do servidor.')
    .addUserOption(option => option.setName('usuário').setDescription('Usuário a ser expulso').setRequired(true))
    .addStringOption(option => option.setName('motivo').setDescription('Motivo da expulsão').setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),

  async execute(interaction) {
    const user = interaction.options.getUser('usuário');
    const reason = interaction.options.getString('motivo') || 'Sem motivo fornecido.';
    const member = interaction.guild.members.cache.get(user.id);

    if (!member) {
      return interaction.reply({ content: 'Usuário não encontrado no servidor.', ephemeral: true });
    }

    if (!member.kickable) {
      return interaction.reply({ content: 'Não posso expulsar esse usuário.', ephemeral: true });
    }

    await member.kick(reason);

    const embed = new EmbedBuilder()
      .setTitle('Usuário Expulso')
      .setDescription(`👢 ${user.tag} foi expulso.
Motivo: ${reason}`)
      .setColor('DarkButNotBlack')
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};
