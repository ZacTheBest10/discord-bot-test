const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Bane um membro do servidor.')
    .addUserOption(option => option.setName('usuário').setDescription('Usuário a ser banido').setRequired(true))
    .addStringOption(option => option.setName('motivo').setDescription('Motivo do banimento').setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

  async execute(interaction) {
    const user = interaction.options.getUser('usuário');
    const reason = interaction.options.getString('motivo') || 'Sem motivo fornecido.';
    const member = interaction.guild.members.cache.get(user.id);

    if (!member) {
      return interaction.reply({ content: 'Usuário não encontrado no servidor.', ephemeral: true });
    }

    if (!member.bannable) {
      return interaction.reply({ content: 'Não posso banir esse usuário.', ephemeral: true });
    }

    await member.ban({ reason });

    const embed = new EmbedBuilder()
      .setTitle('Usuário Banido')
      .setDescription(`🔨 ${user.tag} foi banido.
Motivo: ${reason}`)
      .setColor('DarkRed')
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  }
};
