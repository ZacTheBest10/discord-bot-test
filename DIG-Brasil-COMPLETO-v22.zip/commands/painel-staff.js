const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('painel-staff')
        .setDescription('Exibe o painel de gerenciamento da staff.'),
    async execute(interaction) {
        if (!interaction.member.permissions.has('Administrator')) {
            return interaction.reply({ content: '❌ Você não tem permissão para usar este comando.', ephemeral: true });
        }

        const embed = new EmbedBuilder()
            .setTitle('Painel da Staff')
            .setDescription('Utilize os botões abaixo para acessar diferentes áreas de moderação.')
            .setColor('#2f3136')
            .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
            .addFields(
                { name: '📊 Estatísticas Gerais', value: 'Visualize informações resumidas do servidor.' },
                { name: '🧹 Limpar Mensagens', value: 'Acesse a ferramenta de limpeza de mensagens.' },
                { name: '🔒 Lock/Unlock', value: 'Gerencie o bloqueio de canais rapidamente.' },
            )
            .setFooter({ text: 'DIG Brasil • Painel da Staff' });

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('estatisticas_gerais')
                .setLabel('📊 Estatísticas')
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId('limpar_mensagens')
                .setLabel('🧹 Limpar Mensagens')
                .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
                .setCustomId('bloquear_canal')
                .setLabel('🔒 Lock/Unlock')
                .setStyle(ButtonStyle.Danger),
        );

        await interaction.reply({ embeds: [embed], components: [row] });
    }
};
