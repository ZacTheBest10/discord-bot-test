const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType, PermissionsBitField } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ticket')
        .setDescription('Cria o painel de tickets com botões'),

    async execute(interaction) {
        const embed = new EmbedBuilder()
            .setTitle('🎫 Central de Suporte')
            .setDescription('Clique no botão abaixo de acordo com o tipo de atendimento que você deseja.

🛠️ Suporte Geral
🔒 Denúncia
📝 Sugestão')
            .setColor(0x1c1c1c);

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('ticket_suporte')
                .setLabel('🛠️ Suporte')
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId('ticket_denuncia')
                .setLabel('🔒 Denúncia')
                .setStyle(ButtonStyle.Danger),
            new ButtonBuilder()
                .setCustomId('ticket_sugestao')
                .setLabel('📝 Sugestão')
                .setStyle(ButtonStyle.Success)
        );

        await interaction.reply({ embeds: [embed], components: [row] });
    }
};