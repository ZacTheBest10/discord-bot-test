const { SlashCommandBuilder, EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('verificar')
        .setDescription('Envia um painel de verificação por botão')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .addChannelOption(opt =>
            opt.setName('canal')
                .setDescription('Canal onde será enviado o painel')
                .setRequired(true))
        .addRoleOption(opt =>
            opt.setName('cargo')
                .setDescription('Cargo que será atribuído após a verificação')
                .setRequired(true)),

    async execute(interaction) {
        const canal = interaction.options.getChannel('canal');
        const cargo = interaction.options.getRole('cargo');

        const embed = new EmbedBuilder()
            .setTitle('✅ Verificação')
            .setDescription('Clique no botão abaixo para verificar sua conta e acessar o servidor.')
            .setColor('#065f46');

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId(`verificar_usuario_${cargo.id}`)
                .setLabel('Verificar')
                .setStyle(ButtonStyle.Success)
        );

        await canal.send({ embeds: [embed], components: [row] });

        await interaction.reply({ content: '✅ Painel de verificação enviado com sucesso!', ephemeral: true });
    }
};