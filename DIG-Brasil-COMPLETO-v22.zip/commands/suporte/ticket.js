const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, ChannelType, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ticket')
    .setDescription('Cria um painel de suporte com botão.'),

  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setTitle('🎫 Suporte - DIG Brasil')
      .setDescription('Clique no botão abaixo para abrir um ticket com a equipe de suporte.')
      .setImage('https://i.imgur.com/o8fV4JW.png')
      .setColor('#0B3D91'); // Azul-Marinho

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('abrir_ticket')
        .setLabel('Abrir Ticket')
        .setStyle(ButtonStyle.Primary)
    );

    await interaction.reply({ embeds: [embed], components: [row] });
  }
};