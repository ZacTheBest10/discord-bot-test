const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('contador')
        .setDescription('Configura o sistema de contadores do servidor (membros, online, data de criação).')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute(interaction) {
        const guild = interaction.guild;
        const totalMembros = guild.memberCount;
        const online = guild.members.cache.filter(m => m.presence?.status === 'online').size;
        const dataCriacao = guild.createdAt.toLocaleDateString('pt-BR');

        const categoria = await guild.channels.create({
            name: '📊｜Contadores',
            type: 4,
            position: 0
        });

        await guild.channels.create({
            name: `👥 Total: ${totalMembros}`,
            type: 0,
            parent: categoria,
            permissionOverwrites: [{ id: guild.id, deny: ['SendMessages'] }]
        });

        await guild.channels.create({
            name: `🟢 Online: ${online}`,
            type: 0,
            parent: categoria,
            permissionOverwrites: [{ id: guild.id, deny: ['SendMessages'] }]
        });

        await guild.channels.create({
            name: `📆 Criado em: ${dataCriacao}`,
            type: 0,
            parent: categoria,
            permissionOverwrites: [{ id: guild.id, deny: ['SendMessages'] }]
        });

        await interaction.reply({ content: '✅ Contadores criados com sucesso no topo do servidor!', ephemeral: true });
    }
};