const { SlashCommandBuilder, EmbedBuilder, ButtonBuilder, ActionRowBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('painel')
        .setDescription('Cria um painel de cargos por botão.'),
    async execute(interaction) {
        const embed = new EmbedBuilder()
            .setTitle('🎮 Escolha seus cargos')
            .setDescription('Clique nos botões abaixo para receber ou remover cargos!')
            .setColor('#0D1B2A');

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('cargo_games')
                .setLabel('🎮 Gamer')
                .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
                .setCustomId('cargo_aviso')
                .setLabel('📢 Receber Avisos')
                .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
                .setCustomId('cargo_eventos')
                .setLabel('🎉 Eventos')
                .setStyle(ButtonStyle.Secondary)
        );

        await interaction.reply({ embeds: [embed], components: [row] });
    }
};