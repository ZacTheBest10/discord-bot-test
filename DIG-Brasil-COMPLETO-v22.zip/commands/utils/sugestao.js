const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('sugestao')
        .setDescription('Envie uma sugestão para o servidor.')
        .addStringOption(option => 
            option.setName('mensagem')
                .setDescription('Sua sugestão')
                .setRequired(true)),
    async execute(interaction) {
        const sugestao = interaction.options.getString('mensagem');
        const sugestaoChannel = interaction.guild.channels.cache.find(c => c.name === '📬sugestoes');

        if (!sugestaoChannel) {
            return interaction.reply({ content: '❌ Canal de sugestões não encontrado. Crie um canal chamado 📬sugestoes.', ephemeral: true });
        }

        const embed = new EmbedBuilder()
            .setTitle('💡 Nova Sugestão')
            .setDescription(sugestao)
            .addFields({ name: 'Autor', value: interaction.user.tag })
            .setColor('#1B263B')
            .setTimestamp();

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('sugestao_aprovar')
                .setLabel('Aprovar')
                .setStyle(ButtonStyle.Success),
            new ButtonBuilder()
                .setCustomId('sugestao_rejeitar')
                .setLabel('Rejeitar')
                .setStyle(ButtonStyle.Danger)
        );

        await sugestaoChannel.send({ embeds: [embed], components: [row] });
        await interaction.reply({ content: '✅ Sua sugestão foi enviada com sucesso!', ephemeral: true });
    }
};