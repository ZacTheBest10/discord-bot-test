const { SlashCommandBuilder, PermissionFlagsBits, ButtonBuilder, ButtonStyle, ActionRowBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('registro')
        .setDescription('Cria um painel de verificação para novos membros.'),
        
    async execute(interaction) {
        const embed = new EmbedBuilder()
            .setTitle('📋 Verificação - DIG Brasil')
            .setDescription('Clique no botão abaixo para confirmar que você não é um robô e acessar o servidor.')
            .setColor('#3E3E3E')
            .setImage('https://i.imgur.com/4M34hi2.png');

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('verificar_usuario')
                .setLabel('Verificar')
                .setStyle(ButtonStyle.Success)
        );

        await interaction.reply({ embeds: [embed], components: [row] });
    }
};