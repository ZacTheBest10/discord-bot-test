const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const confirmar = require('../../utils/confirmacao');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Expulsa um membro do servidor.')
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers)
    .addUserOption(option =>
      option.setName('usuário').setDescription('Usuário para expulsar').setRequired(true))
    .addStringOption(option =>
      option.setName('motivo').setDescription('Motivo da expulsão')),

  async execute(interaction) {
    const user = interaction.options.getUser('usuário');
    const reason = interaction.options.getString('motivo') || 'Não especificado';
    const member = await interaction.guild.members.fetch(user.id);

    confirmar(interaction, `expulsar ${user.tag}`, async () => {
      await member.kick(reason);
    });
  }
};