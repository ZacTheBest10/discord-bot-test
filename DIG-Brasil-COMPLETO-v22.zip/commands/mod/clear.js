const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const confirmar = require('../../utils/confirmacao');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('clear')
    .setDescription('Limpa mensagens de um canal.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addIntegerOption(option =>
      option.setName('quantidade').setDescription('Número de mensagens').setRequired(true)),

  async execute(interaction) {
    const quantidade = interaction.options.getInteger('quantidade');

    confirmar(interaction, `limpar ${quantidade} mensagens`, async () => {
      const mensagens = await interaction.channel.bulkDelete(quantidade, true);
    });
  }
};