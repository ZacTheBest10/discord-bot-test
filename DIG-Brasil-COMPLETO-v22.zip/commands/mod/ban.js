const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const confirmar = require('../../utils/confirmacao');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Bane um membro do servidor.')
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addUserOption(option =>
      option.setName('usuário').setDescription('Usuário para banir').setRequired(true))
    .addStringOption(option =>
      option.setName('motivo').setDescription('Motivo do banimento')),

  async execute(interaction) {
    const user = interaction.options.getUser('usuário');
    const reason = interaction.options.getString('motivo') || 'Não especificado';
    const member = await interaction.guild.members.fetch(user.id);

    confirmar(interaction, `banir ${user.tag}`, async () => {
      await member.ban({ reason });
    });
  }
};