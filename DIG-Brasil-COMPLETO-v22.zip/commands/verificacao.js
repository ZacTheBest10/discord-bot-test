const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('verificacao')
        .setDescription('Envia embed de verificação para os membros.')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute(interaction) {
        const embed = new EmbedBuilder()
            .setTitle('✅ Verificação')
            .setDescription('Clique no botão abaixo para verificar-se e acessar o servidor.')
            .setColor('#0a9396');

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('botaoVerificar')
                .setLabel('Verificar')
                .setStyle(ButtonStyle.Success)
        );

        await interaction.reply({ embeds: [embed], components: [row] });
    }
};
