const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ping')
    .setDescription('Veja o ping do bot.'),
  async execute(interaction) {
    const msg = await interaction.reply({ content: '🏓 Pingando...', fetchReply: true });
    interaction.editReply(`🏓 Pong! Latência: ${msg.createdTimestamp - interaction.createdTimestamp}ms`);
  }
};
