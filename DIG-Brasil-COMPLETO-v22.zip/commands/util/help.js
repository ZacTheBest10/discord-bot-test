const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('Veja todos os comandos disponíveis.'),
  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setTitle('📖 Comandos do DIG Brasil')
      .setDescription('Lista de comandos disponíveis:')
      .addFields(
        { name: '/ping', value: 'Veja o ping do bot.' },
        { name: '/ban', value: 'Bane um membro.' },
        { name: '/kick', value: 'Expulsa um membro.' },
        { name: '/clear', value: 'Limpa mensagens do canal.' }
      )
      .setImage('https://i.imgur.com/F4j1qX0.png')
      .setColor('#0D1B2A');

    await interaction.reply({ embeds: [embed] });
  }
};
