const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('userinfo')
    .setDescription('Exibe informações sobre um usuário.')
    .addUserOption(option => option.setName('usuário').setDescription('Usuário para consultar').setRequired(false)),

  async execute(interaction) {
    const user = interaction.options.getUser('usuário') || interaction.user;
    const member = interaction.guild.members.cache.get(user.id);

    const embed = new EmbedBuilder()
      .setTitle('👤 Informações do Usuário')
      .setColor('#1C1C1C')
      .setThumbnail(user.displayAvatarURL({ dynamic: true }))
      .addFields(
        { name: 'Usuário', value: `${user.tag}`, inline: true },
        { name: 'ID', value: `${user.id}`, inline: true },
        { name: 'Conta criada em', value: `<t:${parseInt(user.createdTimestamp / 1000)}:R>`, inline: true },
        { name: 'Entrou no servidor', value: `<t:${parseInt(member.joinedTimestamp / 1000)}:R>`, inline: true }
      );

    await interaction.reply({ embeds: [embed] });
  }
};
