const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const userDataPath = path.join(__dirname, '..', 'database', 'recompensas.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ranking')
        .setDescription('Mostra o ranking dos membros com mais nível'),

    async execute(interaction) {
        const raw = fs.readFileSync(userDataPath);
        const dados = JSON.parse(raw);

        const lista = Object.entries(dados)
            .sort((a, b) => b[1].nivel - a[1].nivel || b[1].mensagens - a[1].mensagens)
            .slice(0, 10);

        const ranking = await Promise.all(lista.map(async ([id, stats], index) => {
            try {
                const membro = await interaction.guild.members.fetch(id);
                return `**${index + 1}.** ${membro.user.username} — Nível ${stats.nivel} (${stats.mensagens} msgs)`;
            } catch {
                return null;
            }
        }));

        const embed = new EmbedBuilder()
            .setColor('#1f2937')
            .setTitle('🏆 Top 10 membros mais ativos')
            .setDescription(ranking.filter(Boolean).join('\n') || 'Nenhum membro com atividade registrada ainda.');

        await interaction.reply({ embeds: [embed] });
    }
};