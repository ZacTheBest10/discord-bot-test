const { SlashCommandBuilder, ChannelType, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('configurar-contadores')
        .setDescription('Configura os canais de contadores de membros')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .addChannelOption(option =>
            option.setName('total')
                .setDescription('Canal para total de membros')
                .addChannelTypes(ChannelType.GuildVoice))
        .addChannelOption(option =>
            option.setName('online')
                .setDescription('Canal para membros online')
                .addChannelTypes(ChannelType.GuildVoice))
        .addChannelOption(option =>
            option.setName('criado')
                .setDescription('Canal para data de criação do servidor')
                .addChannelTypes(ChannelType.GuildVoice)),

    async execute(interaction) {
        const totalChannel = interaction.options.getChannel('total');
        const onlineChannel = interaction.options.getChannel('online');
        const criadoChannel = interaction.options.getChannel('criado');

        const db = require('../database/contadores.json');

        db[interaction.guild.id] = {
            total: totalChannel?.id,
            online: onlineChannel?.id,
            criado: criadoChannel?.id
        };

        require('fs').writeFileSync('./database/contadores.json', JSON.stringify(db, null, 4));

        await interaction.reply({ content: '✅ Contadores configurados com sucesso!', ephemeral: true });
    }
};