const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('baterponto')
        .setDescription('Registra o horário de entrada de um membro da staff.'),
    async execute(interaction) {
        const cargoStaff = interaction.member.roles.cache.find(role => role.name.toLowerCase().includes('staff'));

        if (!cargoStaff) {
            return interaction.reply({ content: '❌ Este comando é apenas para membros da staff.', ephemeral: true });
        }

        const logPath = path.join(__dirname, '../../database/pontos.txt');
        const horario = new Date().toLocaleString('pt-BR');
        const registro = `[${horario}] ${interaction.user.tag} bateu ponto.
`;

        fs.appendFileSync(logPath, registro);

        const embed = new EmbedBuilder()
            .setTitle('🕓 Ponto registrado')
            .setDescription(`✅ Seu ponto foi registrado com sucesso!

**Horário:** ${horario}`)
            .setColor('#1A1A1A');

        await interaction.reply({ embeds: [embed], ephemeral: true });
    }
};