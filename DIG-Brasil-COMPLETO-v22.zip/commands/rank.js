const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const userDataPath = path.join(__dirname, '..', 'database', 'recompensas.json');
let userData = {};

if (fs.existsSync(userDataPath)) {
    userData = JSON.parse(fs.readFileSync(userDataPath));
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('rank')
        .setDescription('Mostra seu nível ou o ranking completo')
        .addUserOption(opt =>
            opt.setName('usuário')
                .setDescription('Usuário para ver o nível individual')),

    async execute(interaction) {
        const membro = interaction.options.getUser('usuário') || interaction.user;

        if (!userData[membro.id]) {
            return await interaction.reply({ content: `❌ ${membro.username} ainda não tem nenhum nível registrado.`, ephemeral: true });
        }

        const { mensagens, nivel } = userData[membro.id];

        const embed = new EmbedBuilder()
            .setColor('#1f2937')
            .setTitle(`🏅 Nível de ${membro.username}`)
            .setDescription(`Mensagens: **${mensagens}**
Nível atual: **${nivel}**`)
            .setThumbnail(membro.displayAvatarURL({ dynamic: true }));

        await interaction.reply({ embeds: [embed] });
    }
};